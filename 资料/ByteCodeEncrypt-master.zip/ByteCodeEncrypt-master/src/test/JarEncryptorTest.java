package test;


import com.seaboat.bytecode.JarEncryptor;
/**
 * 
 * @author seaboat
 * @date 2017-07-06
 * @version 1.0
 * <pre><b>email: </b>849586227@qq.com</pre>
 * <pre><b>blog: </b>http://blog.csdn.net/wangyangzhizhou</pre>
 * <p>JarEncryptor tester.</p>
 */
public class JarEncryptorTest {

  public static void main(String[] args){
    JarEncryptor.encrypt("C:\\Users\\wj\\Desktop\\test.jar");
  }
}
