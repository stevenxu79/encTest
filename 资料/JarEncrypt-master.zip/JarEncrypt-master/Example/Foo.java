// Foo.java

public class Foo
{
  public Foo() {
    System.out.println( "foo" );
  }
}