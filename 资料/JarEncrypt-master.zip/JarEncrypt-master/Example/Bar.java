// Bar.java

public class Bar
{
  public Bar() {
    System.out.println( "bar" );
  }
}


    
